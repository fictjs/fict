import { __fictUseContext } from "fict/internal";
import { __fictUseSignal } from "fict/internal";
import { __fictReactive } from "fict/internal";
import { createElement } from "fict/internal";
import { __fictElementNamespaceMatches } from "fict/internal";
import { createKeyedList } from "fict/internal/list";
import { insert } from "fict/internal";
import { resolvePath } from "fict/internal";
import { onDestroy } from "fict/internal";
import { bindAttribute } from "fict/internal";
import { bindProperty } from "fict/internal";
import { bindClass } from "fict/internal";
import { addEventListener } from "fict/internal";
import { template } from "fict/internal";
const __fict_tmpl0 = template("<div class=\"col-sm-6 smallpad\"><button class=\"btn btn-primary btn-block\" type=\"button\"><!----></button></div>");
const __fict_tmpl1 = template("<div class=\"container\"><div class=\"jumbotron\"><div class=\"row\"><div class=\"col-md-6\"><h1>Fict Keyed</h1></div><div class=\"col-md-6\"><div class=\"row\"><!----><!----><!----><!----><!----><!----></div></div></div></div><table class=\"table table-hover table-striped test-data\"><tbody><!----><!----></tbody></table><span class=\"preloadicon glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></div>");
const __fict_tmpl2 = template("<tr><td class=\"col-md-1\"></td><td class=\"col-md-4\"><a></a></td><td class=\"col-md-1\"><a><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></a></td><td class=\"col-md-6\"></td></tr>");
import { render, createSelector, batch, untrack } from "fict";
import { createSignal } from "fict/advanced";
const adjectives = [
	"pretty",
	"large",
	"big",
	"small",
	"tall",
	"short",
	"long",
	"handsome",
	"plain",
	"quaint",
	"clean",
	"elegant",
	"easy",
	"angry",
	"crazy",
	"helpful",
	"mushy",
	"odd",
	"unsightly",
	"adorable",
	"important",
	"inexpensive",
	"cheap",
	"expensive",
	"fancy"
];
const colours = [
	"red",
	"yellow",
	"blue",
	"green",
	"pink",
	"brown",
	"purple",
	"brown",
	"white",
	"black",
	"orange"
];
const nouns = [
	"table",
	"chair",
	"house",
	"bbq",
	"desk",
	"car",
	"pony",
	"cookie",
	"sandwich",
	"burger",
	"pizza",
	"mouse",
	"keyboard"
];
let nextId = 1;
function random(max) {
	return Math.round(Math.random() * 1e3) % max;
}
function buildData(count) {
	const data = new Array(count);
	for (let i = 0; i < count; i++) {
		data[i] = {
			id: nextId++,
			label: createSignal(`${adjectives[random(adjectives.length)]} ${colours[random(colours.length)]} ${nouns[random(nouns.length)]}`)
		};
	}
	return data;
}
function Button(props) {
	return __fictElementNamespaceMatches("div", "html") ? (() => {
		const __fict_jsx7 = __fict_tmpl0();
		const __fict_node1 = resolvePath(__fict_jsx7, [0], true);
		const __fict_node2 = resolvePath(__fict_jsx7, [0, 0], true);
		bindAttribute(__fict_node1, "id", () => props.id);
		addEventListener(__fict_node1, "click", props.onClick, true);
		insert(__fict_node1, () => props.text, __fict_node2, createElement);
		return __fict_jsx7;
	})() : {
		type: "div",
		props: {
			class: "col-sm-6 smallpad",
			children: {
				type: "button",
				props: {
					id: __fictReactive(() => props.id),
					class: "btn btn-primary btn-block",
					type: "button",
					onClick: props.onClick,
					children: __fictReactive(() => props.text)
				}
			}
		}
	};
}
function App() {
	const __fictCtx = __fictUseContext();
	let data = __fictUseSignal(__fictCtx, [], { name: "data" });
	let selected = __fictUseSignal(__fictCtx, null, { name: "selected" });
	const isSelected = createSelector(() => selected());
	const run = () => {
		((__fict_value) => (data(__fict_value), __fict_value))(buildData(1e3));
		((__fict_value) => (selected(__fict_value), __fict_value))(null);
	};
	const runLots = () => {
		((__fict_value) => (data(__fict_value), __fict_value))(buildData(1e4));
		((__fict_value) => (selected(__fict_value), __fict_value))(null);
	};
	const add = () => {
		((__fict_value) => (data(__fict_value), __fict_value))([...data(), ...buildData(1e3)]);
	};
	const update = () => {
		batch(() => {
			// An event consumes the current rows once; label bindings own their live reads.
			untrack(() => {
				for (let i = 0, rows = data(); i < rows.length; i += 10) {
					const label = rows[i].label;
					label(label() + " !!!");
				}
			});
		});
	};
	const swapRows = () => {
		const list = data();
		if (list.length <= 998) return;
		const copy = list.slice();
		const tmp = copy[1];
		copy[1] = copy[998];
		copy[998] = tmp;
		((__fict_value) => (data(__fict_value), __fict_value))(copy);
	};
	const clear = () => {
		((__fict_value) => (data(__fict_value), __fict_value))([]);
		((__fict_value) => (selected(__fict_value), __fict_value))(null);
	};
	const remove = (id) => {
		const rows = data();
		const index = rows.findIndex((row) => row.id === id);
		if (index >= 0) {
			const next = rows.slice();
			next.splice(index, 1);
			((__fict_value) => (data(__fict_value), __fict_value))(next);
		}
		if (selected() === id) {
			((__fict_value) => (selected(__fict_value), __fict_value))(null);
		}
	};
	const select = (id) => {
		((__fict_value) => (selected(__fict_value), __fict_value))(id);
	};
	return __fictElementNamespaceMatches("div", "html") ? (() => {
		const __fict_jsx39 = __fict_tmpl1();
		const __fict_node8 = resolvePath(__fict_jsx39, [
			0,
			0,
			1,
			0
		], true);
		const __fict_node9 = resolvePath(__fict_jsx39, [
			0,
			0,
			1,
			0,
			0
		], true);
		const __fict_node10 = resolvePath(__fict_jsx39, [
			0,
			0,
			1,
			0,
			1
		], true);
		const __fict_node11 = resolvePath(__fict_jsx39, [
			0,
			0,
			1,
			0,
			2
		], true);
		const __fict_node12 = resolvePath(__fict_jsx39, [
			0,
			0,
			1,
			0,
			3
		], true);
		const __fict_node13 = resolvePath(__fict_jsx39, [
			0,
			0,
			1,
			0,
			4
		], true);
		const __fict_node14 = resolvePath(__fict_jsx39, [
			0,
			0,
			1,
			0,
			5
		], true);
		const __fict_node15 = resolvePath(__fict_jsx39, [1, 0], true);
		const __fict_node16 = resolvePath(__fict_jsx39, [
			1,
			0,
			0
		], true);
		const __fict_node17 = resolvePath(__fict_jsx39, [
			1,
			0,
			1
		], true);
		insert(__fict_node8, () => ({
			type: Button,
			props: {
				id: "run",
				text: "Create 1,000 rows",
				onClick: run
			}
		}), __fict_node9, createElement);
		insert(__fict_node8, () => ({
			type: Button,
			props: {
				id: "runlots",
				text: "Create 10,000 rows",
				onClick: runLots
			}
		}), __fict_node10, createElement);
		insert(__fict_node8, () => ({
			type: Button,
			props: {
				id: "add",
				text: "Append 1,000 rows",
				onClick: add
			}
		}), __fict_node11, createElement);
		insert(__fict_node8, () => ({
			type: Button,
			props: {
				id: "update",
				text: "Update every 10th row",
				onClick: update
			}
		}), __fict_node12, createElement);
		insert(__fict_node8, () => ({
			type: Button,
			props: {
				id: "clear",
				text: "Clear",
				onClick: clear
			}
		}), __fict_node13, createElement);
		insert(__fict_node8, () => ({
			type: Button,
			props: {
				id: "swaprows",
				text: "Swap Rows",
				onClick: swapRows
			}
		}), __fict_node14, createElement);
		const __fict_list38 = createKeyedList(() => data(), (item) => item.id, (item, __fict_key) => {
			const row = untrack(() => item());
			return __fictElementNamespaceMatches("tr", "html") ? (() => {
				const __fict_jsx22 = __fict_tmpl2();
				const __fict_node1 = resolvePath(__fict_jsx22, [0], true);
				const __fict_node2 = resolvePath(__fict_jsx22, [1, 0], true);
				const __fict_node3 = resolvePath(__fict_jsx22, [2, 0], true);
				bindClass(__fict_jsx22, () => isSelected(row.id) ? "danger" : "");
				bindProperty(__fict_node1, "textContent", () => row.id);
				addEventListener(__fict_node2, "click", (...__fictArgs) => {
					(() => select(row.id))(...__fictArgs);
				}, true);
				bindProperty(__fict_node2, "textContent", () => row.label());
				addEventListener(__fict_node3, "click", (...__fictArgs) => {
					(() => remove(row.id))(...__fictArgs);
				}, true);
				return __fict_jsx22;
			})() : {
				type: "tr",
				props: {
					class: __fictReactive(() => isSelected(row.id) ? "danger" : ""),
					children: [
						{
							type: "td",
							props: {
								class: "col-md-1",
								textContent: row.id
							}
						},
						{
							type: "td",
							props: {
								class: "col-md-4",
								children: {
									type: "a",
									props: {
										onClick: () => select(row.id),
										textContent: __fictReactive(() => row.label())
									}
								}
							}
						},
						{
							type: "td",
							props: {
								class: "col-md-1",
								children: {
									type: "a",
									props: {
										onClick: () => remove(row.id),
										children: {
											type: "span",
											props: {
												class: "glyphicon glyphicon-remove",
												"aria-hidden": "true"
											}
										}
									}
								}
							}
						},
						{
							type: "td",
							props: { class: "col-md-6" }
						}
					]
				}
			};
		}, false, __fict_node16, __fict_node17, true, "html");
		__fict_list38.flush?.();
		onDestroy(__fict_list38.dispose);
		return __fict_jsx39;
	})() : {
		type: "div",
		props: {
			class: "container",
			children: [
				{
					type: "div",
					props: {
						class: "jumbotron",
						children: {
							type: "div",
							props: {
								class: "row",
								children: [{
									type: "div",
									props: {
										class: "col-md-6",
										children: {
											type: "h1",
											props: { children: "Fict Keyed" }
										}
									}
								}, {
									type: "div",
									props: {
										class: "col-md-6",
										children: {
											type: "div",
											props: {
												class: "row",
												children: [
													{
														type: Button,
														props: {
															id: "run",
															text: "Create 1,000 rows",
															onClick: run
														}
													},
													{
														type: Button,
														props: {
															id: "runlots",
															text: "Create 10,000 rows",
															onClick: runLots
														}
													},
													{
														type: Button,
														props: {
															id: "add",
															text: "Append 1,000 rows",
															onClick: add
														}
													},
													{
														type: Button,
														props: {
															id: "update",
															text: "Update every 10th row",
															onClick: update
														}
													},
													{
														type: Button,
														props: {
															id: "clear",
															text: "Clear",
															onClick: clear
														}
													},
													{
														type: Button,
														props: {
															id: "swaprows",
															text: "Swap Rows",
															onClick: swapRows
														}
													}
												]
											}
										}
									}
								}]
							}
						}
					}
				},
				{
					type: "table",
					props: {
						class: "table table-hover table-striped test-data",
						children: {
							type: "tbody",
							props: { children: __fictReactive(() => data().map((item) => {
								const row = untrack(() => item);
								return {
									type: "tr",
									props: {
										...(item.id, null),
										class: __fictReactive(() => isSelected(row.id) ? "danger" : ""),
										children: [
											{
												type: "td",
												props: {
													class: "col-md-1",
													textContent: row.id
												}
											},
											{
												type: "td",
												props: {
													class: "col-md-4",
													children: {
														type: "a",
														props: {
															onClick: () => select(row.id),
															textContent: __fictReactive(() => row.label())
														}
													}
												}
											},
											{
												type: "td",
												props: {
													class: "col-md-1",
													children: {
														type: "a",
														props: {
															onClick: () => remove(row.id),
															children: {
																type: "span",
																props: {
																	class: "glyphicon glyphicon-remove",
																	"aria-hidden": "true"
																}
															}
														}
													}
												}
											},
											{
												type: "td",
												props: { class: "col-md-6" }
											}
										]
									}
								};
							})) }
						}
					}
				},
				{
					type: "span",
					props: {
						class: "preloadicon glyphicon glyphicon-remove",
						"aria-hidden": "true"
					}
				}
			]
		}
	};
}
const app = document.getElementById("main");
if (app) {
	render(() => ({
		type: App,
		props: null
	}), app);
}
export default App;
